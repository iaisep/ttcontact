
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section className="pt-28 pb-20 px-4 md:px-8">
      <div className="container mx-auto max-w-6xl">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2 space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Your Vision,<br />
              <span className="text-blue-600">Our Solution</span>
            </h1>
            <p className="text-lg text-gray-600 max-w-md">
              Transform your business with our cutting-edge platform designed to drive growth and deliver results.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="gap-2">
                Get Started
                <ArrowRight size={18} />
              </Button>
              <Button variant="outline" size="lg">
                Learn More
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 relative">
            <div className="bg-blue-600 rounded-3xl w-full aspect-video overflow-hidden shadow-xl transform hover:scale-[1.01] transition-transform">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-blue-700/80 mix-blend-overlay"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-white/90 backdrop-blur-sm rounded-lg p-8 shadow-lg max-w-xs">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                    <div className="text-sm font-medium">Analytics Dashboard</div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-2 bg-gray-200 rounded-full w-full"></div>
                    <div className="h-2 bg-gray-200 rounded-full w-3/4"></div>
                    <div className="h-2 bg-gray-200 rounded-full w-1/2"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
