
import TestPanel from './TestPanel';

export { TestPanel };
export default TestPanel;
