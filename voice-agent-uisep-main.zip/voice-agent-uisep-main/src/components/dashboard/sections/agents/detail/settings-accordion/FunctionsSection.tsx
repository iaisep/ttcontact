
// This file is now importing from the modular implementation
export { default } from './functions/FunctionsSection';
export * from './functions/types';
