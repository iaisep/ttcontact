
import VoiceSelector from './VoiceSelector';

export { VoiceSelector };
export default VoiceSelector;
