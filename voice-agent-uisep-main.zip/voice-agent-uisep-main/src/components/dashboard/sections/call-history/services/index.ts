
export { useCallHistoryService } from './callHistoryService';
export { useCallDetailsService } from './callDetailsService';
