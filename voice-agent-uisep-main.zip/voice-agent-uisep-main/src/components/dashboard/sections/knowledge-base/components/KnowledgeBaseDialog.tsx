
import React from 'react';
import KnowledgeBaseDialog from './dialogs/KnowledgeBaseDialog';

export default KnowledgeBaseDialog;
