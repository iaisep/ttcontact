
import { useKnowledgeBaseDialog } from './dialog';

// Re-export the hook for backward compatibility
export { useKnowledgeBaseDialog };
