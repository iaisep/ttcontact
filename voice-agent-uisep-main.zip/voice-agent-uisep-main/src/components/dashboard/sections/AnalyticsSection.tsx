
// This file now imports from the modular implementation
export { default } from './analytics';
