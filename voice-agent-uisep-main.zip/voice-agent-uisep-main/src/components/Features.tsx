
import { Check } from "lucide-react";

const FeatureCard = ({ title, description }: { title: string; description: string }) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
    <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-4">
      <Check size={20} />
    </div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

const Features = () => {
  const features = [
    {
      title: "Fast Integration",
      description: "Seamlessly integrate our platform with your existing systems in minutes, not days.",
    },
    {
      title: "Powerful Analytics",
      description: "Gain valuable insights with our advanced analytics and reporting tools.",
    },
    {
      title: "Secure & Reliable",
      description: "Enterprise-grade security and 99.9% uptime guarantee for peace of mind.",
    },
    {
      title: "24/7 Support",
      description: "Our dedicated team is always available to help you resolve any issues.",
    },
    {
      title: "Customizable",
      description: "Tailor our platform to your specific needs with extensive customization options.",
    },
    {
      title: "Cost Effective",
      description: "Get more value with competitive pricing and flexible payment plans.",
    },
  ];

  return (
    <section id="features" className="py-20 bg-gray-50 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Features You'll Love</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our platform is packed with features designed to help your business succeed.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
