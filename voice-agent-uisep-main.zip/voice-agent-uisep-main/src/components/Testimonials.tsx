
import { Star } from "lucide-react";

const TestimonialCard = ({ name, role, content, rating = 5 }: 
  { name: string; role: string; content: string; rating?: number }) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
    <div className="flex mb-4">
      {[...Array(rating)].map((_, i) => (
        <Star key={i} size={16} fill="#FFC107" color="#FFC107" />
      ))}
    </div>
    <p className="text-gray-700 mb-6 italic">"{content}"</p>
    <div>
      <p className="font-medium">{name}</p>
      <p className="text-sm text-gray-500">{role}</p>
    </div>
  </div>
);

const Testimonials = () => {
  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Marketing Director",
      content: "This platform transformed our marketing efforts. We've seen a 40% increase in lead generation since implementing it.",
      rating: 5
    },
    {
      name: "Michael Chen",
      role: "CTO, TechStart Inc.",
      content: "The integration was seamless and the support team was incredibly responsive. Exactly what we needed for our growing business.",
      rating: 5
    },
    {
      name: "Emma Rodriguez",
      role: "Small Business Owner",
      content: "As someone with limited technical knowledge, I found this platform intuitive and easy to use. It's made a real difference to my business.",
      rating: 4
    }
  ];

  return (
    <section id="testimonials" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it – hear from some of our satisfied clients.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard 
              key={index}
              name={testimonial.name}
              role={testimonial.role}
              content={testimonial.content}
              rating={testimonial.rating}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
