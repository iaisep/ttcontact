
import UnderConstructionPage from "@/components/ui/UnderConstructionPage";
import { useLanguage } from "@/context/LanguageContext";

const GDPRPage = () => {
  return <UnderConstructionPage title="GDPR" />;
};

export default GDPRPage;
