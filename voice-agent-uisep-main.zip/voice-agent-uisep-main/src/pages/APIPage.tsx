
import UnderConstructionPage from "@/components/ui/UnderConstructionPage";

const APIPage = () => {
  return <UnderConstructionPage title="API" />;
};

export default APIPage;
